



<?php


// try{

 $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root',  '');


//    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   echo "Connected successfully";
// }
//  catch(PDOException $e) {
//   echo "Connection failed: " . $e->getMessage();
// }

//$connect=mysqli_connect("localhost","root","","reg");
// Check connection
// if ($dbh->connect_error) {

//   die("Connection failed: " . $dbh->connect_error);
// }
// else

// echo "Connected successfully";


  if (isset($_POST['reg'])) {

$name = $_POST['name'];

$email = $_POST['email'];

$password = $_POST['password'];

$confirm_password = $_POST['confirm_password'];





// $sql= mysqli_query( $dbh, "INSERT INTO `reg_info`(`name`, `email`, `password`, `confirm_password`) VALUES ('$name','$email','$password','confirm_password')");

$sql=  "INSERT INTO `regis`(`name`, `email`, `password`, `confirm_password`) VALUES ('$name','$email','$password','$confirm_password')";

$dbh->query($sql);

 if(isset($sql)){
      echo '<script type"script/text">alert("Data insert successfully")</script>';
    }
    else{
      echo "unsucess";
    }

}



?>


<!DOCTYPE html>
<html>
<head>
	<title>loginform</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


</head>
<body>


<div class="container">
<div class="row offset-md-2"> 
  <div class="col-lg-10">
<div class="card  text-white bg-secondary pt-5 ">

	  <div class="card-header" style="text-align: center; background-color:blue">
    Registration Form
  </div>
  <div class="card-body">
  	
  	<form method="POST">
 <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

 <div class="form-group">
    <label for="exampleInputEmail1">Full name</label>
    <input name="name"  type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Full name">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>

    <div class="form-group">
    <label for="exampleInputPassword1">Confirm password</label>
    <input name="confirm_password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm password">
  </div>

 <div class="text-center">
  <button name="reg" type="submit" class="btn btn-primary btn-lg">Submit</button>
</div>

</form>

<div>
</div>
</div>
</div>
</div>

</body>
</html>
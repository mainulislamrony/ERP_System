<?php

$name = $_POST['name'];

$email = $_POST['email'];

$id = $_POST['id'];

 $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root', '',[

PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION
 ]);
  

$sql = "UPDATE `regis` SET `name` =:name ,`email` =:email  WHERE id =:id";

$stm = $dbh->prepare($sql);


$stm->bindParam('name', $name);

$stm->bindParam('email', $email);

$stm->bindParam('id', $id);

$stm->execute();




header('Location: ../view/view.php');

<?php



 $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root',  '');


if (isset($_GET['id'])) {


    $stm = $dbh->prepare("SELECT * FROM regis where id=:id");

    $stm->bindParam('id', $_GET['id']);

    $stm->execute();

    $user = $stm->fetch(PDO::FETCH_ASSOC);

}


?>


<!DOCTYPE html>
<html>
<head>
	<title>loginform</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


</head>
<body>


<div class="container">
<div class="row offset-md-2"> 
  <div class="col-lg-10">
<div class="card  text-white bg-secondary pt-5 ">

	  <div class="card-header" style="text-align: center; background-color:blue">
    Registration Form
  </div>
  <div class="card-body">
  	
  	<form method="POST" action="userupdate.php" >
 <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

 <div class="form-group">
    <label for="exampleInputEmail1">Full name</label>
    <input name="name" value="<?php echo $user['name'] ?>" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Full name">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input name="email" type="email" value="<?php echo $user['email'] ?>"class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input name="password" type="text" class="form-control"value="<?php echo $user['password'] ?>" id="exampleInputPassword1" placeholder="Password">
  </div>

    <div class="form-group">
    <label for="exampleInputPassword1">Confirm password</label>
    <input name="confirm_password" type="text" class="form-control" id="exampleInputPassword1" value="<?php echo $user['confirm_password'] ?>"placeholder="Confirm password">
  </div>

 <div class="text-center">
  <button name="reg" type="submit" class="btn btn-primary btn-lg">
       
  Update</button>
</div>

</form>

<div>
</div>
</div>
</div>
</div>

</body>
</html>
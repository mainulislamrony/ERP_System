<?php



 $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root',  '');


$id = '';

if (isset($_GET['id'])) {

    $id = (int) $_GET['id'];

}

$stm = $dbh->prepare('DELETE FROM regis WHERE id = :id');

$stm->bindParam('id', $id);

$stm->execute();


header('Location: ../view/view.php');

?>



<?php include_once '../partial/navbar.php' ?>


<?php
  $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root',  '');

 $sql= "SELECT * FROM `regis`";
$result=$dbh->query($sql);
$stores=$result->fetchAll(PDO::FETCH_ASSOC);

?>

          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          <h2>Section title</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>id</th>
                  <th>user nsme</th>
                  <th>email</th>
                  <th>password</th>
                  <th>confirm_password</th>
                   <th>Action</th>
                </tr>
              </thead>
              <tbody>
               
                     <?php foreach ($stores as $key => $value) : ?>

                            <tr>

                                <td><?php echo $value['id']?></td>

                                <td><?php echo $value['name'] ?></td>

                                <td><?php echo $value['email']?></td>

                                <td><?php echo $value['password']?></td>

                                <td><?php echo $value['confirm_password']?></td>

                                <td>

                                    <a href="useredit.php?id=<?php echo $value['id'] ?>" class="btn btn-info">Edit</a>

                                    <a href="userdelete.php?id=<?php echo $value['id'] ?>"

                                       class="btn btn-danger">Delete</a>

                                </td>

                            </tr>

                        <?php endforeach; ?>
     
              </tbody>
        </table>
          </div>
        </main>
      </div>
    </div>

@extends('admin.backend.layout.main')
@section('main')
<table id="customers">

      <tr>
        <th >Serial</th>
        <th >Name</th>
        <th >image</th>
        <th >Email</th>
        <th >Registration time</th>
        <th >Action</th>
      </tr>

        @foreach ($view as $item=>$user)


      <tr>
      <td>{{$item+1}}</td>
      <td>{{$user->name}}</td>
      <td>
      <img src="{{URL::to($user->image)}}"  style="height:80px; width:80px" alt="" class="rounded">
      </td>
        <td>{{$user->email}}</td>
        <td>{{$user->created_at}}</td>
        <td>
            <a  class="btn btn-primary" href="{{route('admin.edit',$user->id)}}">Edit</a>
        <a class="btn btn-danger" href="{{route('admin.delete',$user->id)}}">Delete</a>
        </td>
      </tr>
      @endforeach



@endsection

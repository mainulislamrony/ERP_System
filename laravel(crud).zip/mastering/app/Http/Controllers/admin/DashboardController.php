<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
public function Dashboard(){

        $total_user=100;
        $total_post=1200;

    return view('admin.backend.dashboard',compact('total_user','total_post'));
}
}

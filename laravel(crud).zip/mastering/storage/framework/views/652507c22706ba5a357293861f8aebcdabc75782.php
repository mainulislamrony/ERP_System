<?php $__env->startSection('main'); ?>

<form>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="text" class="form-control" placeholder="Email">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="text" class="form-control"  placeholder="Name">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mastering\resources\views/admin/backend/database/add_user.blade.php ENDPATH**/ ?>
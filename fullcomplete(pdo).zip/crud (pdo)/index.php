<?php

if(isset($_POST['submit'])){

$name = $_POST['name'];

$email = $_POST['email'];

$subject = $_POST['subject'];

$message =$_POST['message'];

 $dbh = new PDO('mysql:host=localhost;dbname=registration', 'root', '',[

PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION
 ]);
  

$sql = "INSERT INTO `accounts`(`name`, `email`, `subject`, `message`) VALUES ('$name','$email','$subject','$message')";
$stm = $dbh->prepare($sql);


$stm->bindParam('name', $name);

$stm->bindParam('email', $email);

$stm->bindParam('subject', $subject);
$stm->bindParam('message', $message);

$stm->execute();

if(isset($stm)){
      echo '<script type"script/text">alert("Data insert successfully")</script>';
    }

     else{
      echo "unsucess";
    }

}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="css/all.css">

    <title>RAPID PRESERVATION SOLUTION</title>
  </head>
  <body>
  	<div class="container">
   <nav class="navbar navbar-expand-lg navbar-light bg-light" style="color: #B3B6B7;">
  <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active mr-5" >
        <a class="nav-link h5" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active mr-5">
        <a class="nav-link h5" href="#">Services</a>
      </li>
      <li class="nav-item active mr-5">
       <a class="nav-link h5"href="#">Why Us</a>
      </li>
      <li class="nav-item active mr-5">
        <a class="nav-link h5" href="#">Contact</a>
      </li>
    </ul>
    
  </div>
</nav>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="5000">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="img/img1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/img2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/img3.png" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<div class="row ml-1">
<p>
<strong>Rapid Preservation Solution</strong> is property preservation Work Order Processing, Quality Checking & Vendor Management Company.<br><br> 

Your one stop solution for all kinds of work orders you have throughout the year. We provide guaranteed services with quality and unbeatable prices. We are a BPO specializing only on Property Preservation work order processing. We are working in this field with field service companies for a good few years. 
</p>
	
</div>
<div>
  <hr class="my-5" style=" border: 1px solid green;"></div>
  <div class=" ml-5 offset-lg-3" style="max-height:100px;">
  </div>
  
    	<div class="row">
    		<div class="col-md-12">
    			<div class="section-title my-5">
    				<h1 class="text-success text-center">Services</h1>
    			</div>
    			<div class="text-center"><img src="img/service.png"></div>
<p>We feel very lucky having worked in such different vendors, and feel it is giving us a range of knowledge about different software’s, apps and sites. We make our client’s life relax and ensure the quality of work. We focused on just one thing - offshore REO and P&P Work order processing/Quality Checking/Vendor Management) service. We are expert in different types of work orders such as</p>

<ul>
  <li>Securing Orders.</li>
  <li>Grass Cut Orders.</li>
  <li>Winterization Orders.</li>
  <li>Eviction Orders.</li>
  <li>Hazard EOB Orders.</li>
  <li>Maintenance & Snow Removal Orders.</li>
</ul>

  <div class="col-md-12 col-lg-12 text-center">
            <div class="section-title">
              <h1 class="dark-color theme-after theme-before text-center pb-5 text-success">We have worked for</h1>

</div>
<div class="row offset-lg-2" >
	<div class="col-md-4" >
	 <ol class="text-left">
  <li>MCS (Vendor 360)</li>
  <li>Safeguard</li>
  <li>Service Link</li>
  <li>Five Brothers</li>
  <li>NFR</li>
  <li>M&M</li>
  <li>Aspengrove/Guardian</li>
  <li>VRM</li>
</ol>
</div>
<div class="col-md-4">
	 <ol start="9" class="text-left">
  <li>First Allegiance</li>
  <li>United Field Servic</li>
  <li>Altisource</li>
  <li>MSI</li>
  <li>Cyprexx</li>
  <li>North Sight</li>
  <li>ZVN</li>
  <li>Xome Field Service</li>
</ol>
</div>
<div class="col-md-3">
	 <ol start="17" class="text-left">
  <li>Visneta</li>
  <li>A2Z</li>
  <li>Sandcastle</li>
  <li>BLM</li>
  <li>MILES</li>
  <li>Single Source</li>
  <li>Brookstone</li>
  <li>Spectrum</li>
</ol>
</div>
</div>
          </div>
    		</div>
    	</div>

    	<div class="row">
    		<div class="col-md-12">
    			<div class="text-center">
    			<img src="img/photo1.png">
    			</div>
    			<p class="ml-2">We are comfortable with any source you use for Photos & Data - Property Preservation Wizard (PPW), PRUVAN, OneDrive, Google Drive and Dropbox.</p>
    		</div>
    	</div>

    	<div class="row">
    		<div class="col-md-12">
    			<div class="text-center">
    			<img src="img/photo2.png">
    			</div>
    			<p class="ml-2">We prepare convincing bid sheets using various cost estimators like XACTPRM or Repair Base. We search the property details for every order specially for grass cut orders in public records like realquest, trulia, zillow etc. We use Google Earth to find the location and property & lot measurement if no public record is found for any property.</p>
    		</div>
    	</div>
  
<div>

  <hr class="my-5" style=" border: 1px solid green;"></div>


  <div class="row">
  	<div class="col-md-12">
  		<div class="section-title my-5">
    				<h1 class="text-success text-center">Why Choose Us?</h1>
    			</div>


  	
  	<div class="text-center" ><img src="img/chooseus.png" style="height: 500px,width: 250"></div>
<div>

  	<p>We are confident that we will be able to assist any Preservation related work on time with quality
    
  	</p>
  	</div>
  	<div>
  	  <ul>
      	<li> We work 24hrs a day, 7 days a week and have backup processors including holidays.</li>
      	<li>We have a flexible trial period of up to 15 days/15 work orders.</li>
      	<li>No Charge for RTVs/Denial work orders caused by our processors.</li>
      	<li>We will change a separate minimal price for any type of RTVs (which will be half price than usual work order) caused by contractors, in house processors etc.</li>
      	<li>Any property preservation software.</li>
      	<li>Pressure less, Low cost, more profit.</li>
      	<li>We provide consultancy facility to our clients to grow the volume of work.</li>
      	<li> We will provide you with highly experienced and expert processors to process and update your REO and Property Preservation Work Orders to your clients.</li>
      	<li>QC process in place for every single order process.</li>
      	<li> We have knowledge and experience that will surpass anyone else you can find in this industry.</li>
      	<li>We will able to meet your exact needs and requirements and giving you the best result.</li>
      </ul>
      </div>
      <div>

  	<p>We are currently looking for independent contractor/ vendor who want to grow business, be pressure less, consume time & make more profit.<br>Hire us and focus on Strategic Planning to boost your business.
  	</p>
  	</div>
      </div>
  </div>
   <hr class="my-5" style=" border: 1px solid green;">

       <section id="contact" class="section">
      <h1 class="bg-title text-center"></h1>
      <div class="container jumbotron">
        <div class="row justify-content-center m-60px-b sm-m-40px-b">
          <div class="col-md-12 col-lg-12 text-center">
            <div class="section-title">
              <h1 class="dark-color theme-after theme-before text-center pb-5 text-success">Get in touch with us</h1>
              <p style="font-weight: bold;">You have got Questions.<br>We have answers just send us message and one of our knowledgeable Support staff will be contact with <br>You within 24hrs-even on weekends and holidays</p>
            </div>
          </div> <!-- col -->
        </div><!-- row -->

        <div class="row justify-content-center">
          <div class="col-lg-12 md-m-30px-b">
            <div class="contact-form">
                <h4 class="dark-color font-alt m-20px-b text-center"></h4>
                <form action="index.php" method="POST">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <input id="name" name="name" type="text" placeholder="Name" class="validate form-control" required="">
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-group">
                          <input id="email" type="email" placeholder="Email" name="email" class="validate form-control" required="">
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                        </div>
                        <div class="col-md-12">
                        	 <div class="form-group">
                          <input  placeholder="Subject" name="subject" type="text"  class="form-control" required="">
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                        <div class="form-group">
                          <textarea id="message" rows="8" cols="50" placeholder="Your message(optional)" name="message" class="form-control" required=""></textarea>
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                       </div>
                        <div class="col-md-12">
                          <div >
                             <button type="submit" name="submit" class="btn btn-success btn-lg btn text-center">Submit</button>
                          </div>
                          <span class="output_message"></span>
                        </div>
                      </div>
                </form>
            </div>
          </div> <!-- col -->
      
        </div>
      </div> <!-- container -->
    </section>

    <div>
  <hr class="my-5" style=" border: 1px solid green;"></div>

 <footer>

    <!--Social buttons-->
    <div class="social-section text-center jumbotron">

         <hr>

      <ul class="list-unstyled list-inline">
        <li class="list-inline-item"><a class="btn-floating btn-fb fa-2x"><i class="fab fa-facebook-f"> </i></a></li>
        <li class="list-inline-item"><a class="btn-floating btn-tw fa-2x"><i class="fab fa-twitter"> </i></a></li>
        <li class="list-inline-item"><a class="btn-floating btn-gplus fa-2x"><i class="fab fa-google-plus-g"> </i></a></li>
        <li class="list-inline-item"><a class="btn-floating btn-li fa-2x"><i class="fab fa-linkedin-in"> </i></a></li>
        <li class="list-inline-item"><a class="btn-floating btn-git fa-2x"><i class="fab fa-github"> </i></a></li>
      </ul>

        <!--Copyright-->
      <div class="footer-copyright  text-center">
        <div class="container-fluid">
          © 2020 Copyright: <a href="http://www.Bootstrap.com"> Rapid Preservation Solution </a>.All Rights Reserved

        </div>
      </div>
      <!--/.Copyright-->
    </div>
    <!--/.Social buttons-->

    </footer>
    <!--/.Footer-->
</div>


      
  </body>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>
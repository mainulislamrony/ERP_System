<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class insert extends Model
{
    use HasFactory;
    protected $guarded =[];
    protected $table="inserts";

    public function loaninsert(){
        return $this->hasMany(loaninsert::class);
    }
}

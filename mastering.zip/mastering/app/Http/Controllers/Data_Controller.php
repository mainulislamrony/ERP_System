<?php

namespace App\Http\Controllers;

use App\Models\insert;
use App\Models\loaninsert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Throwable;

class Data_Controller extends Controller
{
    public function hello(){
        return view('admin.backend.database.index');
    }

    public function insert(Request $request){

        $request->validate([
            'name'=>'required|min:4',
            'email'=>'required',
        ]);
        $rony= new insert;
        $rony->name=$request->name;
        $rony->email=$request->email;
        $rony->password=bcrypt($request->password);
        $photo=$request->file('image');
        if($photo){
            $name=uniqid();
            $ext=$photo->getClientOriginalExtension();
            $photo_name=$name.'.'.$ext;

            $img_path='upload/';
            $img_url= $img_path.$photo_name;
            $photo->move($img_path,$photo_name);
            $rony->image=$img_url;

        }
        $rony->save();

    }


  public function update(Request $request, $id){
    $insert = insert::find($id);

    $insert->name=$request->name;
    $insert->email=$request->email;
    try{
        $insert->save();
        return redirect()->route('admin.users');
    }catch(Throwable $exception){
        return redirect()->back();
    }
  }


public function all_user(){
    $view= insert::all();
    return view('admin.backend.database.all_users',compact('view'));

}

public function edit($id){
    $insert = insert::find($id);
    return view('admin.backend.database.edit', compact('insert'));

}
public function delete($id){
    $insert=insert::find($id);
    try{
        $insert->delete();
        return redirect()->back();
    }catch(Throwable $exception){
        return redirect()->back();
    }
}

public function loan(){
    return view('admin.backend.database.loan');
}


public function insert_loan(Request $request){
$data=new loaninsert();
$data->Account_number=$request->account_number;
$data->loan=$request->loan;
$data->insert_id=$request->insert_id;
$data->save();
return redirect()->back();

}

}

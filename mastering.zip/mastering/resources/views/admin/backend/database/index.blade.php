@extends('admin.backend.layout.main')
@section('main')
@if($errors->any())
    <ul>
    @foreach ($errors->all() as $error)
    <li>{{$error}}</li>
    @endforeach
</ul>
    @endif
<form action="{{ route('admin.insert') }}" method="post" enctype="multipart/form-data">
    @csrf
    <div class="form-group">
      <label for="exampleInputEmail1">Name</label>
      <input type="text" class="form-control" name="name" aria-describedby="emailHelp" placeholder="Name">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email</label>
      <input type="text" class="form-control" name="email" placeholder="Email">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
      </div>


    <div class="form-group">
        <label for="exampleInputPassword1">image</label>
        <input type="file" name="image" class="form-control" >
      </div>

    <button type="submit" class="btn btn-primary">Save</button>
  </form>
@endsection

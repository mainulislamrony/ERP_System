@extends('admin.backend.layout.main')
@section('main')
<form action="{{route('admin.update',$insert->id)}}" method="post">
    @csrf
    <div class="form-group">
      <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" name="name" value="{{$insert->name}}" aria-describedby="emailHelp" placeholder="Name">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email</label>
    <input type="text" class="form-control" name="email" value="{{$insert->email}}" placeholder="Email">
    </div>
    <button type="submit" class="btn btn-primary">update</button>
  </form>
@endsection

@extends('admin.backend.layout.main')
@section('main')
<form action="{{ route('admin.loan_insert')}}" method="post">
    @csrf
    <div class="form-group">
      <label for="exampleInputEmail1">Account Number</label>
      <input type="text" class="form-control" name="account_number" aria-describedby="emailHelp" placeholder="Account Number">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Loan Amount</label>
      <input type="text" class="form-control" name="loan" placeholder="loan">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Insert Id</label>
        <input type="text" class="form-control" name="insert_id" placeholder="loan">
      </div>

    <button type="submit" class="btn btn-primary">Save</button>
  </form>
@endsection

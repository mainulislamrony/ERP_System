<?php $__env->startSection('main'); ?>
<?php if($errors->any()): ?>
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
    <?php endif; ?>
<form action="<?php echo e(route('admin.insert')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Name</label>
      <input type="text" class="form-control" name="name" aria-describedby="emailHelp" placeholder="Name">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email</label>
      <input type="text" class="form-control" name="email" placeholder="Email">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
      </div>


    <div class="form-group">
        <label for="exampleInputPassword1">image</label>
        <input type="file" name="image" class="form-control" >
      </div>

    <button type="submit" class="btn btn-primary">Save</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mastering\resources\views/admin/backend/database/index.blade.php ENDPATH**/ ?>
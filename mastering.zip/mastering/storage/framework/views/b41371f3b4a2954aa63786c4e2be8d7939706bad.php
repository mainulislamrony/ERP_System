<?php $__env->startSection('main'); ?>
<table id="customers">

      <tr>
        <th >Serial</th>
        <th >Name</th>
        <th >image</th>
        <th >Email</th>
        <th >Registration time</th>
        <th >Action</th>
      </tr>

        <?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


      <tr>
      <td><?php echo e($item+1); ?></td>
      <td><?php echo e($user->name); ?></td>
      <td>
      <img src="<?php echo e(URL::to($user->image)); ?>"  style="height:80px; width:80px" alt="" class="rounded">
      </td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->created_at); ?></td>
        <td>
            <a  class="btn btn-primary" href="<?php echo e(route('admin.edit',$user->id)); ?>">Edit</a>
        <a class="btn btn-danger" href="<?php echo e(route('admin.delete',$user->id)); ?>">Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mastering\resources\views/admin/backend/database/all_users.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>
<form action="<?php echo e(route('admin.loan_insert')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Account Number</label>
      <input type="text" class="form-control" name="account_number" aria-describedby="emailHelp" placeholder="Account Number">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Loan Amount</label>
      <input type="text" class="form-control" name="loan" placeholder="loan">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Insert Id</label>
        <input type="text" class="form-control" name="insert_id" placeholder="loan">
      </div>

    <button type="submit" class="btn btn-primary">Save</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mastering\resources\views/admin/backend/database/loan.blade.php ENDPATH**/ ?>
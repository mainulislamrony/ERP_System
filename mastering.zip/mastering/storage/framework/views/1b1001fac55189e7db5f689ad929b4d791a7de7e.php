<?php $__env->startSection('main'); ?>
<form action="" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Name</label>
      <input type="text" class="form-control" name="name" aria-describedby="emailHelp" placeholder="Name">

    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email</label>
      <input type="text" class="form-control" name="email" placeholder="Email">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
      </div>

    <button type="submit" class="btn btn-primary">Save</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mastering\resources\views/admin/backend/database/view.blade.php ENDPATH**/ ?>
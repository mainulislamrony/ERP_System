<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLoaninsertsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loaninserts', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->string('Account_number');
            $table->string('loan');
            $table->bigInteger('insert_id')->unsigned();
            $table->foreign('insert_id')->references('id')->on('inserts')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loaninserts');
    }
}

<?php

use App\Http\Controllers\admin\DashboardController;
use App\Http\Controllers\Data_Controller;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;
use Symfony\Component\HttpKernel\DataCollector\DataCollector;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


 Route::get('/',[DashboardController::class,'Dashboard'])->name('admin.dashboard');
 Route::get('/post', [PostController::class,'index'])->name('admin.post');

 Route::get('/add_user',[Data_Controller::class,'hello'])->name('admin.add_user');
 Route::post('/insert',[Data_Controller::class,'insert'])->name('admin.insert');
 Route::get('/all_user',[Data_Controller::class,'all_user'])->name('admin.users');
 Route::get('/edit{id}',[Data_Controller::class,'edit'])->name('admin.edit');
 Route::post('/update{id}',[Data_Controller::class,'update'])->name('admin.update');
 Route::get('/delete{id}',[Data_Controller::class,'delete'])->name('admin.delete');

Route::get('/loan',[Data_Controller::class,'loan'])->name('admin.loan');
Route::post('/insert_loan',[Data_Controller::class,'insert_loan'])->name('admin.loan_insert');






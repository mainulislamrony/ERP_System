


<?php
  $dbh = new PDO('mysql:host=localhost;dbname=bank_database', 'root',  '');

 $sql= "SELECT * FROM `account`";
$result=$dbh->query($sql);
$stores=$result->fetchAll(PDO::FETCH_ASSOC);

?>


          <h2 class="text-center">Account List</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Account_Number</th>
                  <th>Branch_Name</th>
                  <th>Balance</th>
                  <th>Customer_ID</th>
                   
                </tr>
              </thead>
              <tbody>
               
                     <?php foreach ($stores as $key => $value):  ?>

                            <tr>

                                <td><?php echo $value['id']?></td>

                                <td><?php echo $value['Account_number'] ?></td>

                                <td><?php echo $value['Branch_name']?></td>

                                <td><?php echo $value['Balance']?></td>

                                <td><?php echo $value['customer_id']?></td>


                            </tr>

                        <?php endforeach; ?>
     
              </tbody>
        </table>
          </div>
        </main>
      </div>
    </div>

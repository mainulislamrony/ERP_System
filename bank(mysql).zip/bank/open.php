<?php
  session_start();

  include("dbConnect.php");


  if (isset($_POST['login'])) {
   $name = $_POST['name'];
   $account_number = $_POST['account_number'];
   $address = $_POST['address'];

    $result = mysqli_query($dbh,"INSERT INTO `depositor`(`Customer_name`, `Account_number`, `coustomer_address`) VALUES ('$name','$account_number','$address')");

    if($result==true)
    {
        ?>
        <script>
        alert('Record inserted...');
        window.location='user.php'
        </script>
        <?php
    }
    else
    {
        ?>
        <script>
        alert('error inserting record...');
        window.location='user.php'
        </script>
        <?php
    }
  }

?>


<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
</head>

<body>
   <div class="container">
     <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Our Banking Management System</a>
        </div>
        <ul class="nav navbar-nav pull-right">
          <li><a href="user.php">Home</a></li>
          <li><a href="logout.php">Logout</a></li>
          
        </ul>
      </div>
     </nav>

     <div class="panel panel-default">
      <div class="panel-heading">
        <h2>Open Account</h2>
      </div>

      <div class="panel-body">
        <div style="max-width: 600px; margin: 0 auto">
        <form action="" method="post">
          <div class="form-group">
            <input type="text" name="name" placeholder="Customer Name" required class="form-control" />
          </div>

          <div class="form-group">
            <input type="text" name="account_number" placeholder="Account Number" required class="form-control" />
          </div>

          <div class="form-group">
            <input type="text" name="address" placeholder="Customer Address" required class="form-control" />
          </div>
          
          <div class="form-group"><p>Select a Branch
             <select name="brName" id="brid" style="width: 150px;box-sizing: border-box;border-radius: 4px;padding: 4px 0px 4px 0px;font-size: 16px;">
                  <option value="Uttara">Uttara</option>
                  <option value="Gazipur">Gazipur</option>
                  <option value="Tangail">Tangail</option>
                  <option value="Barisal">Barisal</option>
                  <option value="Tongi">Tongi</option>
                
             </select>
          </div>

          <button type="submit" name="login" class="btn btn-success">Submit</button>
        </form>
       </div>
      </div>
     </div>

     <div class="well">
      <h3>
         <span class="pull-right"></span>
      </h3>
     </div>   
    
   </div>

</body>
</html>
<?php   

$dbh = mysqli_connect('localhost', 'root', '', 'bank_database');

?>   
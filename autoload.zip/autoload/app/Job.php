<?php 

namespace App;

class Job 

{


}
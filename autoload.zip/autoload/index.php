<?php

require __DIR__.'./vendor/autoload.php';



var_dump(new App\User());

var_dump(new App\Job());
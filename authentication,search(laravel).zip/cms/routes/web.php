<?php

use App\Http\Controllers\Admin\Auth\LoginController;
use App\Http\Controllers\Admin\Dashboard_Controller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => 'guest'], function () {
    Route::get('/', [LoginController::class,'createlogin'])->name('/');
    Route::post('login/Process', [LoginController::class,'loginProcess'])->name('login.process');
});


Route::group(['middleware' => 'auth'], function () {
    Route::get('logout/Process', [LoginController::class,'logoutProces'])->name('logout.process');
    Route::get('dashboard',[Dashboard_Controller::class,'Dashboard'])->name('dashboard');
    Route::get('/admin',[Dashboard_Controller::class,'admin_dashboard'])->name('admin.dashboard');
    Route::get('/client',[Dashboard_Controller::class,'client_dashboard'])->name('client.dashboard');
    Route::get('/add_user',[Dashboard_Controller::class,'adduser_dashboard'])->name('add_user.dashboard');
    Route::post('/insert',[Dashboard_Controller::class,'insert'])->name('insert');
    Route::get('/all_user',[Dashboard_Controller::class,'all_user'])->name('admin.all_user');
    Route::get('/edit{id}',[Dashboard_Controller::class,'edit'])->name('admin.edit');
    Route::post('/update{id}',[Dashboard_Controller::class,'update'])->name('admin.update');
    Route::get('/delete{id}',[Dashboard_Controller::class,'delete'])->name('admin.delete');
    Route::get('/all_products',[Dashboard_Controller::class,'all_products'])->name('admin.all_products');
});

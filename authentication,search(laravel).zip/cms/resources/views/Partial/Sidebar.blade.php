<div class="sidebar sidebar-dark bg-dark">
    <ul class="list-unstyled">
    <li><a href="{{route('dashboard')}}"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>

    <li><a href="{{route('admin.dashboard')}}"><i class="fa fa-fw fa-link"></i> Admin</a></li>
    <li><a href="{{route('client.dashboard')}}"><i class="fa fa-fw fa-link"></i> Client</a></li>
    <li><a href="{{route('add_user.dashboard')}}"><i class="fa fa-fw fa-link"></i>Add User</a></li>
    <li><a href="{{route('admin.all_user')}}"><i class="fa fa-fw fa-link"></i>All User</a></li>
    <li><a href="{{route('admin.all_products')}}"><i class="fa fa-fw fa-link"></i>All Products</a></li>


    </ul>
</div>

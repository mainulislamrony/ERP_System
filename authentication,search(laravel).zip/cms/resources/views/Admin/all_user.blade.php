@extends('Layout.Main')
@section('main')
<table id="" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Serial</th>
            <th>Name</th>
            <th>Email</th>
            <th>Image</th>
            <th>Start date</th>
            <th>Action</th>

        </tr>
    </thead>
    <tbody>
    <tr>
        @foreach ($user as $item=>$view)

     <td>{{$item+1}}</td>
     <td>{{$view->name}}</td>
      <td>{{$view->email}}</td>
    <td><img src="{{URL::to($view->image)}}" style="height:80px; width:80px" class="rounded-circle"></td>
    <td>{{$view->created_at->diffForHumans()}}</td>
    <td>
    <a href="{{route('admin.edit',$view->id)}}" class="btn btn-primary">Edit</a>
    <a href="{{route('admin.delete',$view->id)}}" class="btn btn-danger">Delete</a>
    </td>
    </tr>
    </tbody>
    @endforeach
  </table>
  <div>{{$user->links()}}</div>

@endsection

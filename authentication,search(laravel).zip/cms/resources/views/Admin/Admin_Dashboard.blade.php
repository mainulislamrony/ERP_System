@extends('Layout.Main')
@section('user_name')
Admin name
@endsection
@section('main')
<div class="col-sm-12">
    <div class="container">
      <h1 class="text-primary"><i class="fas fa-tachometer-alt"></i> Dashboard <small>Statics Overview</small></h1>
    </div>
    <div>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
         </nav>
        <div class="row">


          <div class="col-lg-4">
            <div class="card ">
              <div class="card-body text-white bg-primary">
                <div class="row">
                  <div class="col-lg-7"><i class="fas fa-user fa-5x"></i></div>
                  <div class="col-lg-5">
                    <div><h1>10</h1></div>
                    <div class="clearfix">All Employee</div>
                  </div>
                </div>
              </div>
              <a href="#">
              <div class="card-footer">
                <span class="">All Employees</span>
                <div class="float-right"><i class="fas fa-user"></i></div>
              </div>
            </a>
            </div>
          </div>


          <div class="col-lg-4">
            <div class="card ">
              <div class="card-body text-white bg-primary">
                <div class="row">
                  <div class="col-lg-7"><i class="fas fa-user fa-5x"></i></div>
                  <div class="col-lg-5">
                    <div><h1>10</h1></div>
                    <div class="clearfix">View Profile</div>
                  </div>
                </div>
              </div>
              <a href="#">
              <div class="card-footer">
                <span class="">View Profile</span>
                <div class="float-right"><i class="fas fa-user"></i></div>
              </div>
            </a>
            </div>
          </div>
        </div>
        </div>
         </div>
@endsection

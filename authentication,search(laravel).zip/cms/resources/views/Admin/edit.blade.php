
@extends('Layout.Main')
@section('main')



<form action="{{route('admin.update',$edit->id)}}" method="POST">
    @csrf
    <div class="form-group">
        <label for="exampleInputPassword1">Name</label>
    <input type="text" class="form-control" name="name" placeholder="Name" value="{{$edit->name}}">
      </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" name="email" value="{{$edit->email}}" aria-describedby="emailHelp" placeholder="Enter email">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>


    <button type="submit" class="btn btn-primary">Update</button>
  </form>
@endsection

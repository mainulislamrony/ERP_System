@extends('Layout.Main')
@section('main')


<nav class="navbar navbar-light bg-light">
  <form class="form-inline" action="{{route('admin.all_products')}}" >
    <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search" aria-label="Search" value="{{request()->query('search')}}">
    <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>
<hr class="my-4">
<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Serial</th>
            <th>Vrand Name</th>
            <th>status</th>
            <th>Category Name</th>
            <th>Status</th>
            <th>Action</th>

        </tr>
    </thead>
    <tbody>
    <tr>
        @foreach ($vrand as $item=>$view)

     <td>{{$item+1}}</td>
     <td>{{$view->vrand_name}}</td>
      <td>{{$view->status}}</td>

    <td>
        @foreach ($view->category as $category)
      {{$category->category}},
      @endforeach

    </td>
   <td>
    @foreach ($view->category as $category)
         {{$category->status}},
         @endforeach
   </td>

    <td>
    <a href="{{route('admin.edit',$view->id)}}" class="btn btn-primary">Edit</a>
    <a href="{{route('admin.delete',$view->id)}}" class="btn btn-danger">Delete</a>
    </td>
    </tr>
    </tbody>
    @endforeach
  </table>
@endsection

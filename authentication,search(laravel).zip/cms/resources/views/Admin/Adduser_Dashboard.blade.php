@extends('Layout.Main')
@section('main')
@if ($errors->any())
@foreach ($errors->all() as $error)
   <div class="text-danger">{{$error}}</div>

@endforeach

@endif
<form action="{{route('insert')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="form-group">
        <label for="exampleInputPassword1">Name</label>
    <input type="text" class="form-control" name="name" value="{{old('name')}}"placeholder="Name">
      </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" name="email" value="{{old('email')}}" aria-describedby="emailHelp" placeholder="Enter email">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" name="password" placeholder="Password">
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Image</label>
        <input type="file" class="form-control" name="image">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
@endsection


<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="{{asset('assets')}}/css/bootstrap.min.css">
<link rel="stylesheet" href="{{asset('assets')}}/css/fontawesome-all.min.css">
<link rel="stylesheet" href="{{asset('assets')}}/css/bootadmin.min.css">

    <title>CSM</title>

    <style>
        #customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
    </style>
</head>
<body class="bg-light">

@include('Partial.Header')

<div class="d-flex">
@include('Partial.Sidebar')

    <div class="content p-4">
     @yield('main')


    </div>
</div>

<script src="{{asset('assets')}}/js/jquery.min.js"></script>
<script src="{{asset('assets')}}/js/bootstrap.bundle.min.js"></script>
<script src="{{asset('assets')}}/js/bootadmin.min.js"></script>

</body>
</html>

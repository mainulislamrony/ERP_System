<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\adduser;
use App\Models\Vrand;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\TryCatch;
use Symfony\Contracts\Service\Attribute\Required;
use Throwable;

class Dashboard_Controller extends Controller
{
    public function Dashboard(){
        return view('Admin.Dashboard');
    }
    public function admin_dashboard(){
        return view('Admin.Admin_Dashboard');
    }
    public function client_dashboard(){
        return view('Admin.Client_Dashboard');
    }
    public function adduser_dashboard(){
        return view('Admin.Adduser_Dashboard');
    }

    public function insert(Request $request){
         $request->validate([
             'name'=>'required|min:3|max:20',
             'email'=>'required',
             'password'=>'required|min:5',

         ]);

     $data =new adduser;
     $data->name=$request->name;
     $data->email=$request->email;
     $data->password=bcrypt($request->password);
     $photo=$request->file('image');
     if($photo){
         $name=uniqid();
         $ext=$photo->getClientOriginalExtension();
         $photo_name=$name.'.'.$ext;

         $img_path='upload/';
         $img_url= $img_path.$photo_name;
         $photo->move($img_path,$photo_name);
         $data->image=$img_url;

     }
     $data->save();
     return Redirect()->back();
    }

    public function all_user(){
        $user= adduser::paginate(10);

        return view('Admin.all_user',compact('user'));
    }

    public function edit($id){
        $edit=adduser::find($id);
        return view('Admin.edit',compact('edit'));

    }

    public function update(Request $request,$id){
        $data=adduser::find($id);

        $data->name=$request->name;
        $data->email=$request->email;

        try{
            $data->save();
            return redirect()->route('admin.all_user');
        }

        catch(Throwable $exception){
            return redirect()->back();
        }

    }

    public function delete($id){
        $delete=adduser::find($id);
        try{
            $delete->delete();
            return redirect()->back();

        }
        catch(Throwable $exception){
            return redirect()->back();
        }

    }


    public function all_products(Request $request){
        $search=$request->query('search');
        $vrand=Vrand::with('category')->get();
        if($search){
            $vrand=Vrand::with('category')
            ->where('vrand_name','like',"%{$search}%")
            ->orWhere('status','like',"%{$search}%")
            ->get();
        }
        return view('Admin.all_products',compact('vrand'));

    }

}

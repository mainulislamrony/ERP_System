<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class LoginController extends Controller
{
    public function createlogin(){
        return view('admin.auth.createlogin');
    }
    public function loginProcess(Request $request){

        $readential = $request->only('email', 'password');

        if(auth()->attempt($readential)){
            return Redirect()->route('dashboard');
        }else{
            session()->flash('error', 'Invalid Email or password');

            return Redirect()->back();
        }
    }
    public function logoutProces(){
        \auth()->logout();
        return Redirect()->route('/');
    }
}
